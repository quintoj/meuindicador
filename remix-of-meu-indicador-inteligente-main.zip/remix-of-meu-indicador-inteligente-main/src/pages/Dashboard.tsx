import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { BarChart3, Plus, Settings, Target, TrendingUp, Users, DollarSign, Percent, Calendar } from "lucide-react";
import { Link } from "react-router-dom";
import KPICard from "@/components/dashboard/KPICard";
import AIChat from "@/components/ai/AIChat";

const Dashboard = () => {
  const [kpis] = useState([
    {
      id: "1",
      name: "Faturamento Mensal",
      value: 85420,
      target: 100000,
      format: "currency" as const,
      icon: DollarSign,
      segment: "Geral"
    },
    {
      id: "2", 
      name: "Ticket Médio",
      value: 127.50,
      target: 150,
      format: "currency" as const,
      icon: TrendingUp,
      segment: "Vendas"
    },
    {
      id: "3",
      name: "Taxa de Conversão",
      value: 23.4,
      target: 25,
      format: "percentage" as const,
      icon: Percent,
      segment: "Marketing"
    },
    {
      id: "4",
      name: "Clientes Ativos",
      value: 892,
      target: 1000,
      format: "number" as const,
      icon: Users,
      segment: "Clientes"
    },
    {
      id: "5",
      name: "Margem Bruta",
      value: 34.2,
      target: 40,
      format: "percentage" as const, 
      icon: TrendingUp,
      segment: "Financeiro"
    },
    {
      id: "6",
      name: "Novos Clientes",
      value: 45,
      target: 50,
      format: "number" as const,
      icon: Users,
      segment: "Aquisição"
    }
  ]);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link to="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-primary rounded-lg flex items-center justify-center">
                <BarChart3 className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-foreground">Meu Gestor</span>
            </Link>
            <Badge variant="secondary" className="ml-4">Academia Fitness</Badge>
          </div>
          <div className="flex items-center space-x-4">
            <Link to="/store">
              <Button variant="outline" className="flex items-center space-x-2">
                <Plus className="w-4 h-4" />
                <span>Adicionar KPI</span>
              </Button>
            </Link>
            <Button variant="outline" size="icon">
              <Settings className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Dashboard Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold text-foreground mb-2">Dashboard</h1>
              <p className="text-muted-foreground">Acompanhe seus indicadores de performance em tempo real</p>
            </div>
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Calendar className="w-4 h-4" />
              <span>Última atualização: hoje às 14:30</span>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <Card className="bg-gradient-success text-white border-0">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm opacity-90">Acima da Meta</p>
                    <p className="text-2xl font-bold">2</p>
                  </div>
                  <Target className="w-8 h-8 opacity-80" />
                </div>
              </CardContent>
            </Card>
            <Card className="bg-gradient-warning text-white border-0">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm opacity-90">Próximo da Meta</p>
                    <p className="text-2xl font-bold">2</p>
                  </div>
                  <Target className="w-8 h-8 opacity-80" />
                </div>
              </CardContent>
            </Card>
            <Card className="bg-gradient-danger text-white border-0">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm opacity-90">Abaixo da Meta</p>
                    <p className="text-2xl font-bold">2</p>
                  </div>
                  <Target className="w-8 h-8 opacity-80" />
                </div>
              </CardContent>
            </Card>
            <Card className="bg-gradient-card border-0">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Total de KPIs</p>
                    <p className="text-2xl font-bold text-foreground">6</p>
                  </div>
                  <BarChart3 className="w-8 h-8 text-primary" />
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* KPIs Grid */}
          <div className="lg:col-span-2">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-semibold text-foreground">Seus Indicadores</h2>
              <div className="flex items-center space-x-2">
                <Input 
                  placeholder="Buscar indicador..." 
                  className="w-64" 
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {kpis.map((kpi) => (
                <KPICard key={kpi.id} kpi={kpi} />
              ))}
            </div>

            {/* Add New KPI Card */}
            <Link to="/store">
              <Card className="mt-6 border-2 border-dashed border-muted-foreground/30 hover:border-primary transition-colors cursor-pointer bg-gradient-card">
                <CardContent className="p-8 text-center">
                  <Plus className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-foreground mb-2">Adicionar Novo KPI</h3>
                  <p className="text-muted-foreground">Escolha entre centenas de indicadores para o seu segmento</p>
                </CardContent>
              </Card>
            </Link>
          </div>

          {/* AI Chat Sidebar */}
          <div className="lg:col-span-1">
            <AIChat />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;